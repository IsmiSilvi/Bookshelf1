// Function to generate unique ID
function generateId() {
    return +new Date(); // Using timestamp as ID
  }
  
  // Function to render books on the shelves
  function renderBooks() {
    const belumDibacaShelf = document.getElementById('listBelumDibaca');
    const sudahDibacaShelf = document.getElementById('listSudahDibaca');
  
    // Clear existing book list
    belumDibacaShelf.innerHTML = '';
    sudahDibacaShelf.innerHTML = '';
  
    // Render books on the shelves
    buku.forEach(book => {
      const li = document.createElement('li');
      li.textContent = `${book.title} - ${book.author} (${book.year})`;
  
      const buttonMove = document.createElement('button');
      buttonMove.textContent = book.isComplete ? 'Belum Selesai Baca' : 'Selesai Baca';
      buttonMove.onclick = () => moveBook(book.id);
  
      const buttonDelete = document.createElement('button');
      buttonDelete.textContent = 'Hapus';
      buttonDelete.onclick = () => deleteBook(book.id);
  
      li.appendChild(buttonMove);
      li.appendChild(buttonDelete);
  
      if (book.isComplete) {
        sudahDibacaShelf.appendChild(li);
      } else {
        belumDibacaShelf.appendChild(li);
      }
    });
  }
  
// Function to add new book
function tambahBuku() {
    const judulInput = document.getElementById('judulBuku').value;
    const tahunInput = Number(document.getElementById('tahunTerbit').value); // Convert to number
    const penulisInput = document.getElementById('namaPenulis').value;
    const selesaiInput = document.getElementById('selesaiDibaca').checked; // Checkbox state
    
    if (judulInput && tahunInput && penulisInput) {
      const newBook = {
        id: generateId(),
        title: judulInput,
        author: penulisInput,
        year: tahunInput,
        isComplete: selesaiInput // Checkbox value
      };
  
      buku.push(newBook);
      renderBooks();
      saveDataToStorage();
    } else {
      alert('Harap lengkapi semua kolom input!');
    }
  }
    
  // Function to move book between shelves
  function moveBook(id) {
    const index = buku.findIndex(book => book.id === id);
    if (index !== -1) {
      buku[index].isComplete = !buku[index].isComplete;
      renderBooks();
      saveDataToStorage();
    }
  }
  
  // Function to delete book
  function deleteBook(id) {
    const index = buku.findIndex(book => book.id === id);
    if (index !== -1) {
      buku.splice(index, 1);
      renderBooks();
      saveDataToStorage();
    }
  }
  
  // Function to save data to localStorage
  function saveDataToStorage() {
    localStorage.setItem('bookshelf_data', JSON.stringify(buku));
  }
  
  // Initialize book data from localStorage or empty array if not exists
  let buku = JSON.parse(localStorage.getItem('bookshelf_data')) || [];
  
  // Render books on page load
  renderBooks();
  